#!/bin/bash

if [[ "$VIRTUAL_ENV" != "" ]]
then
  cd ..
  if [[ $1 == "package" ]]
  then 
    python3 setup.py build bdist_wheel
    pip install dist/MyAPI*
  else
    pip install -r requirements.txt
  fi
else
  echo "Please run in a virtualenv"
fi
