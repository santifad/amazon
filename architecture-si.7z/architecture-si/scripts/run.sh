#!/bin/sh

cd ..
python3 -m MyAPI