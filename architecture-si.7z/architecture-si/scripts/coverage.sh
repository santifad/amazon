#!/bin/sh

cd ..
pytest --cov-report term-missing --cov=MyAPI tests/
