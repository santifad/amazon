#!/bin/sh

cd ..
pytest .
