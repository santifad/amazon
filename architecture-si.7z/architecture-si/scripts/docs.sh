#!/bin/bash

cd ../doc
make html

if [[ $1 != "" ]]
then
  $1 ./build/html/index.html
else
  firefox ./build/html/index.html
fi
