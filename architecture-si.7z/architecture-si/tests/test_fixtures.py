import pytest

from MyAPI.app import app
from MyAPI.init_app import conf_app, init_app
from MyAPI.model.User import User


@pytest.fixture
def flask_client():
    """
    Pytest fixture to help accessing your
    client in tests with a requests-like
    interface. `clear_tables` is useful
    here if you change default DB path.
    """ 
    conf_app(app)
    init_app(app, clear_tables=True)

    with app.test_client() as client:
        yield client
