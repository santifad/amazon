def test_hello(flask_client):
    r = flask_client.get("/hello/")
    assert r.status_code == 200
    assert r.data == b"Hello"


def test_hello_sir(flask_client):
    r = flask_client.get("/hello/romain")
    assert r.status_code == 200
    assert r.data == b"Hello romain"


def test_hello_last_user(flask_client):
    r = flask_client.post("/hello/last_user", json={"user_name": "romain_test1"})
    assert r.status_code == 200
    # In combination with test_hello.test_test_transparency test
    assert r.json["user_id"] == 1
    g = flask_client.get("/hello/last_user")
    assert g.status_code == 200

    assert all([kg in r.json for kg in g.json])
    assert all([kr in g.json for kr in r.json])
    assert all([vr == g.json[kr] for kr, vr in r.json.items()])


def test_test_transparency(flask_client):
    r = flask_client.post("/hello/last_user", json={"user_name": "romain_test2"})
    assert r.json["user_id"] == 1
