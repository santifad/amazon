"""
Entrypoint to run a test in terminal.
To launch it, just run python -m MyAPI

Conf. example if you want to persist your data:
```python
app = conf_app(app, db_link="sqlite:///./db.db")
app = init_app(app)
```
"""

from MyAPI.app import app, conf_app, init_app


app = conf_app(app)
app = init_app(app)
app.run(host="0.0.0.0", port=12345, debug=True)
