import pony.orm as pony
from MyAPI.model.Db import User


@pony.db_session()
def add_user(user):
    return User(user_username=user['user_username'],
                user_email=user['user_email'],
                user_password=user['user_password'],
                )


@pony.db_session()
def check_availability(username, email):
    return len(pony.select(el for el in User if el.user_username == username or el.user_email == email)) < 1
