import pony.orm as pony
from MyAPI.model.Db import Tag


@pony.db_session()
def add_tag(tag):
    return Tag(tag_label=tag['tag_label']
               )


@pony.db_session()
def get_all_tags():
    return [el.to_dict('tag_id tag_label') for el in pony.select(t for t in Tag)]
