import pony.orm as pony
from datetime import datetime
from MyAPI.model.Db import Order, User


@pony.db_session()
def add_order(order):
    return Order(order_date=datetime.now(),
                 order_products=order['order_products'],
                 order_user=User[order['order_user']]
                 ).to_dict('order_products order_date')


@pony.db_session()
def get_user_orders(order_user):
    return [el.to_dict('order_products order_date') for el in pony.select(o for o in Order if o.order_user == order_user)]
