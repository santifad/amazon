import pony.orm as pony
from MyAPI.model.Db import Product, Tag


@pony.db_session()
def add_product(product):
    return Product(product_name=product['product_name'],
                   product_price=product['product_price'],
                   product_delivery_time=product['product_delivery_time'],
                   product_stock=product['product_stock'],
                   product_score=product['product_score'],
                   product_description=product['product_description'],
                   product_image_link=product['product_image_link'],
                   product_tag=Tag[product['product_tag']]
                   )\
        .to_dict('product_id product_name product_price product_stock product_score product_description product_image_link product_tag')


@pony.db_session()
def get_product(product_id):
    return Product[product_id]\
        .to_dict('product_id product_name product_price product_stock product_score product_description product_image_link product_tag')


@pony.db_session()
def search_product_by_name(name):
    return [el.to_dict('product_id product_name product_price product_stock product_score product_description product_image_link product_tag')
            for el in pony.select(p for p in Product if name.lower() in p.product_name.lower())]
