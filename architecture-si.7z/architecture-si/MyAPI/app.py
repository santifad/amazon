from flask import Flask

from MyAPI.init_app import conf_app, init_app


app = Flask(__name__)
