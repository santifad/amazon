from flask import Blueprint, Flask, render_template, request, redirect, url_for
import hashlib
from MyAPI.controller.user import add_user, check_availability

login_bp = Blueprint("login", __name__, url_prefix="/login")


def init_login_bp(app: Flask, **kwargs) -> Flask:
    app.register_blueprint(login_bp)
    return app


@login_bp.route("/log/", methods=["GET"])
def login_page():
    return render_template("login.html", username=request.args.get('username'))


@login_bp.route("/", methods=["POST"])
def login():
    username = request.form['username']
    password = request.form['password']
    if False:
        return redirect(url_for('nav.home'))
    return redirect(url_for("login.login_page", username=username))


@login_bp.route("/register/form/", methods=["POST"])
def register():
    username = request.form['username']
    email = request.form['email']
    password = hashlib.sha256(request.form['password'].encode('utf-8')).hexdigest()
    if check_availability(username, email):
        add_user({'user_username': username, 'user_email': email, 'user_password': password})
        return redirect(url_for("login.login_page"))
    return redirect(url_for("login.register_page", used=True))


@login_bp.route("/register/", methods=["GET"])
def register_page():
    return render_template("register.html", used=request.args.get('used'))

