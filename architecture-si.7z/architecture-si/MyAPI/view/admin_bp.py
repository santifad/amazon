from flask import Blueprint, Flask, render_template, request, redirect, url_for

from MyAPI.controller.product import add_product
from MyAPI.controller.tag import add_tag

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


def init_admin_bp(app: Flask, **kwargs) -> Flask:
    app.register_blueprint(admin_bp)
    return app


@admin_bp.route("/", methods=["GET"])
def admin_page():
    return render_template("admin.html")


@admin_bp.route("/product/", methods=["GET"])
def admin_product_page():
    return render_template("add_product.html", added=request.args.get('added'))


@admin_bp.route("/product/add/", methods=["POST"])
def admin_product_add():
    product = {
        'product_name': request.form['name'],
        'product_price': request.form['price'],
        'product_description': request.form['desc'],
        'product_image_link': request.form['image_link'],
        'product_delivery_time': request.form['delivery_time'],
        'product_stock': request.form['stock'],
        'product_score': None,
        'product_tag': request.form['tag']
    }
    if product['product_stock'] == '':
        product['product_stock'] = None
    add_product(product)
    return redirect(url_for("admin.admin_product_page", added=True))


@admin_bp.route("/tag/", methods=["GET"])
def admin_tag_page():
    return render_template("add_tag.html", added=request.args.get('added'))


@admin_bp.route("/tag/add/", methods=["POST"])
def admin_tag_add():
    tag = {
        'tag_label': request.form['name']
    }
    add_tag(tag)
    return redirect(url_for("admin.admin_tag_page", added=True))
