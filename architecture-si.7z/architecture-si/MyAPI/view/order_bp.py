from flask import Blueprint, Flask, render_template, request, jsonify

from MyAPI.controller.order import add_order

order_bp = Blueprint("order", __name__, url_prefix="/order")


def init_order_bp(app: Flask, **kwargs) -> Flask:
    app.register_blueprint(order_bp)
    return app


@order_bp.route("/<order_id>", methods=["GET"])
def get_order(order_id):
    return "Order's data : " + order_id


@order_bp.route("/place/", methods=["POST"])
def place_order():
    order_dict = {
        'order_products': request.form['order_products'],
        'order_user': 1
    }
    # return "Place order"
    return jsonify(add_order(order_dict))
