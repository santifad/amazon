from flask import Blueprint, Flask, render_template, request

nav_bp = Blueprint("nav", __name__, url_prefix="")


def init_nav_bp(app: Flask, **kwargs) -> Flask:
    app.register_blueprint(nav_bp)
    return app


@nav_bp.route("/", methods=["GET"])
def home():
    return render_template("home.html")
