from flask import Blueprint, Flask, render_template, request, jsonify
from MyAPI.controller.product import *
from MyAPI.controller.tag import get_all_tags

product_bp = Blueprint("product", __name__, url_prefix="/product")


def init_product_bp(app: Flask, **kwargs) -> Flask:
    app.register_blueprint(product_bp)
    return app


@product_bp.route("/<product_id>", methods=["GET"])
def product_page(product_id):
    return render_template("product.html", product=product_id)


@product_bp.route("/data/<product_id>", methods=["GET"])
def get_product_data(product_id):
    return get_product(product_id)


@product_bp.route("/search/result/", methods=["POST"])
def search_product_page():
    return render_template("search_result.html", name=request.form['name'])


@product_bp.route("/search/<name>", methods=["GET"])
def search_product(name):
    return jsonify(search_product_by_name(name))


@product_bp.route("/tags/", methods=["GET"])
def get_tags():
    return jsonify(get_all_tags())
