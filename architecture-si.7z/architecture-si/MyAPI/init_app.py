from flask import Flask

from MyAPI.view.admin_bp import init_admin_bp
from MyAPI.view.product_bp import init_product_bp
from MyAPI.view.login_bp import init_login_bp
from MyAPI.view.order_bp import init_order_bp
from MyAPI.view.nav_bp import init_nav_bp


def conf_app(app: Flask, **kwargs) -> Flask:
    """
    Place to set app configuration 
    """
    if "db_link" not in kwargs:
        app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///test.sqlite"
    else:
        app.config["SQLALCHEMY_DATABASE_URI"] = kwargs["db_link"]
    return app


def init_app(app: Flask, **kwargs) -> Flask:
    """
    Links DB to Flask session and add the blueprint
    we defined to the known URLs 
    """
    # app = init_db(app, **kwargs)
    app = init_nav_bp(app, **kwargs)
    app = init_login_bp(app, **kwargs)
    app = init_admin_bp(app, **kwargs)
    app = init_product_bp(app, **kwargs)
    app = init_order_bp(app, **kwargs)
    return app
