import pony.orm as pony
from datetime import datetime


db = pony.Database()
pony.set_sql_debug(False)


class Product(db.Entity):
    product_id = pony.PrimaryKey(int, auto=True)
    product_name = pony.Required(str)
    product_price = pony.Required(float)
    product_delivery_time = pony.Optional(str)
    product_stock = pony.Optional(int)
    product_score = pony.Optional(float)
    product_description = pony.Required(str)
    product_image_link = pony.Required(str)
    product_tag = pony.Set('Tag')
    product_comment = pony.Set('Comment')


class Tag(db.Entity):
    tag_id = pony.PrimaryKey(int, auto=True)
    tag_label = pony.Required(str, unique=True)
    tag_product = pony.Set(Product)


class User(db.Entity):
    user_id = pony.PrimaryKey(int, auto=True)
    user_username = pony.Required(str, unique=True)
    user_password = pony.Required(str)
    user_email = pony.Required(str, unique=True)
    user_comment = pony.Set('Comment')
    user_order = pony.Set('Order')
    user_cart = pony.Set('Cart')


class Comment(db.Entity):
    comment_id = pony.PrimaryKey(int, auto=True)
    comment_user = pony.Required(User)
    comment_product = pony.Required(Product)
    comment_content = pony.Required(str)


class Order(db.Entity):
    order_id = pony.PrimaryKey(int, auto=True)
    order_user = pony.Required(User)
    order_date = pony.Required(datetime)
    order_products = pony.Required(pony.Json)


class Cart(db.Entity):
    cart_id = pony.PrimaryKey(int, auto=True)
    cart_user = pony.Required(User)
    cart_products = pony.Required(pony.Json)


db.bind(provider='sqlite', filename='../test.sqlite', create_db=True)

db.generate_mapping(create_tables=True)
