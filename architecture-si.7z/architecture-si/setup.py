import setuptools

with open("README.md", mode="r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", mode="r", encoding="utf-8") as f:
    requirements = [r.strip() for r in f.readlines()]

setuptools.setup(
    name="MyAPI",
    version="0.0.1",
    author="Alexandre",
    author_email="Alexandre",
    description="A small flask example package",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="alexandre.com",
    install_requires=requirements,
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)