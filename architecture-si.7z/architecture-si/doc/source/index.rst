.. MyAPI documentation master file, created by
   sphinx-quickstart on Sat Jan 23 03:42:19 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to MyAPI's documentation!
=================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   model


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. mdinclude:: ../../README.md