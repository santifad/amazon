Model
=====

.. autoclass:: MyAPI.model.User.User
   :members:
   :undoc-members:
