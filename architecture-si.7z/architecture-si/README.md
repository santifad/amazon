You can find every examples you need in ./scripts.
A few things before starting:

1) Scripts must be ran from ./scripts folder
2) install.sh must be ran in a virtualenv
3) To check rendered template, go see
   http://localhost:12345/hello/page/my_name

When changing the code, please take into
account these few things:

1) You can access Swagger UI on:
`http://0.0.0.0:12345/api/docs/#/`, but to
add new endpoints, you will need to docstring
to the function (or `MethodViews`), otherwise they
will be ignored by Swagger. Also, doctstrings
in hello_bp are minimal, more parameters are
described on page:
`https://pypi.org/project/flask-swagger/`
2) To add Blueprints, do not forget to register
them in `MyAPI.init_app.init_app` keeping
`swagger_bp` in last, we never know what
could happen.
2) If you are a bit lost with the mapping,
you can find a way to check if your path is
defined by calling `url_map()` somewhere you
know you have access to, like calling
`print(str(Swaggerify.app.url_map()))` in
`MyAPI.view.swagger_bp.spec`, it will be
called when checking swagger.